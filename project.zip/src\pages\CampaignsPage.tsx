import { useState, useEffect, useRef, useMemo, useCallback } from "react";
import { Plus, Megaphone, Send, Clock, FileText, AlertCircle, Search, Target, CalendarDays, Upload, X, Eye, Users, Check, Ban, MessageSquare, BarChart3, ArrowRight, Download, ShoppingCart, TrendingUp, Mail, MailOpen, Reply, XCircle, GitCompareArrows, ChevronDown, ChevronUp, AlertTriangle, Shield, Repeat, RefreshCw, RotateCcw, ExternalLink } from "lucide-react";
import CampaignSafetyTips from "@/components/campaigns/CampaignSafetyTips";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { supabase, invokeCloud } from "@/lib/supabase";
import { useAuth } from "@/contexts/AuthContext";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "recharts";
import * as XLSX from "xlsx";

const statusConfig: Record<string, { label: string; icon: any; className: string }> = {
  draft: { label: "مسودة", icon: FileText, className: "bg-muted text-muted-foreground" },
  scheduled: { label: "مجدولة", icon: Clock, className: "bg-info/10 text-info" },
  queued: { label: "في الطابور", icon: Clock, className: "bg-info/10 text-info" },
  sending: { label: "جاري الإرسال", icon: Send, className: "bg-warning/10 text-warning" },
  paused: { label: "متوقفة مؤقتاً", icon: Clock, className: "bg-warning/10 text-warning" },
  sent: { label: "تم الإرسال", icon: Check, className: "bg-success/10 text-success" },
  failed: { label: "فشل", icon: AlertCircle, className: "bg-destructive/10 text-destructive" },
  recurring: { label: "متكررة", icon: Repeat, className: "bg-primary/10 text-primary" },
};

interface Recipient {
  phone: string;
  name?: string;
  variables?: Record<string, string>;
}

const CampaignsPage = () => {
  const { orgId, isEcommerce, hasMetaApi } = useAuth();
  const [campaigns, setCampaigns] = useState<any[]>([]);
  const [customers, setCustomers] = useState<any[]>([]);
  const [tagDefs, setTagDefs] = useState<any[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  const [whatsappChannels, setWhatsappChannels] = useState<any[]>([]);
  const [showCreate, setShowCreate] = useState(false);
  const [detailCampaign, setDetailCampaign] = useState<any>(null);
  const [recipients, setRecipients] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [compareMode, setCompareMode] = useState(false);
  const [compareIds, setCompareIds] = useState<string[]>([]);
  const [showCompare, setShowCompare] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  // Create form
  const [form, setForm] = useState({
    name: "", templateName: "", templateLang: "ar", scheduledAt: "", notes: "",
    audienceType: "all" as string,
    audienceTags: [] as string[],
    excludeTags: [] as string[],
    excludeCampaignIds: [] as string[],
    variableColumns: [] as string[],
    channelId: "" as string,
    messageText: "" as string,
    delaySeconds: 10 as number,
    recurringType: "" as string,
    recurringEndAt: "" as string,
    // E-commerce filters
    filterProduct: "",
    filterCity: "",
    filterDateFrom: "",
    filterDateTo: "",
    filterMinAmount: "",
    filterMaxAmount: "",
  });
  const [uploadedRecipients, setUploadedRecipients] = useState<Recipient[]>([]);
  const [selectedCustomerIds, setSelectedCustomerIds] = useState<string[]>([]);
  const [templateVars, setTemplateVars] = useState<string[]>([]);

  useEffect(() => {
    if (orgId) load();
  }, [orgId]);

  const load = async () => {
    const [c, cust, tags, channels] = await Promise.all([
      supabase.from("campaigns").select("*").eq("org_id", orgId!).order("created_at", { ascending: false }),
      supabase.from("customers").select("*").eq("org_id", orgId!),
      supabase.from("customer_tag_definitions").select("*").eq("org_id", orgId!),
      supabase.from("whatsapp_config_safe").select("*").eq("org_id", orgId!).eq("is_connected", true),
    ]);
    setCampaigns(c.data || []);
    setCustomers(cust.data || []);
    setTagDefs(tags.data || []);
    setWhatsappChannels(channels.data || []);
    if (isEcommerce && orgId) {
      const [o, p] = await Promise.all([
        supabase.from("orders").select("*").eq("org_id", orgId),
        supabase.from("products").select("id, name, name_ar").eq("org_id", orgId),
      ]);
      setOrders(o.data || []);
      setProducts(p.data || []);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    let headers: string[] = [];
    let rows: string[][] = [];

    if (file.name.endsWith(".xlsx") || file.name.endsWith(".xls")) {
      const buffer = await file.arrayBuffer();
      const wb = XLSX.read(buffer, { type: "array" });
      const ws = wb.Sheets[wb.SheetNames[0]];
      const data = XLSX.utils.sheet_to_json<string[]>(ws, { header: 1 });
      if (data.length === 0) { toast.error("الملف فارغ"); return; }
      headers = (data[0] || []).map((h) => String(h).trim().toLowerCase());
      rows = data.slice(1).map((row) => row.map((cell) => String(cell || "").trim()));
    } else {
      const text = await file.text();
      const lines = text.split("\n").filter(Boolean);
      headers = lines[0].split(",").map((h) => h.replace(/"/g, "").trim().toLowerCase());
      rows = lines.slice(1).map((line) => line.split(",").map((s) => s.replace(/"/g, "").trim()));
    }

    const phoneIdx = headers.findIndex((h) => h.includes("phone") || h.includes("رقم") || h.includes("جوال"));
    const nameIdx = headers.findIndex((h) => h.includes("name") || h.includes("اسم"));

    if (phoneIdx === -1) { toast.error("لم يتم العثور على عمود الأرقام — تأكد من وجود عمود phone أو رقم"); return; }

    const varCols = headers.filter((_, i) => i !== phoneIdx && i !== nameIdx);
    setForm((f) => ({ ...f, variableColumns: varCols }));

    const recs: Recipient[] = [];
    for (const parts of rows) {
      const phone = parts[phoneIdx];
      if (!phone) continue;
      const vars: Record<string, string> = {};
      varCols.forEach((col) => {
        const idx = headers.indexOf(col);
        if (idx >= 0) vars[col] = parts[idx] || "";
      });
      recs.push({ phone, name: nameIdx >= 0 ? parts[nameIdx] : undefined, variables: vars });
    }
    setUploadedRecipients(recs);
    toast.success(`تم تحميل ${recs.length} رقم من الملف`);
    if (fileRef.current) fileRef.current.value = "";
  };

  const getEcommerceFilteredCustomers = () => {
    // Get customer phones from orders matching e-commerce filters
    let filteredOrders = [...orders];
    if (form.filterProduct) {
      // We need order_items but we don't have them loaded — filter by customer or skip
      // For now filter orders that have the product name in notes/tags (simplified)
      filteredOrders = filteredOrders.filter(o => o.customer_name?.includes(form.filterProduct) || o.notes?.includes(form.filterProduct));
    }
    if (form.filterCity) {
      filteredOrders = filteredOrders.filter(o => o.customer_city === form.filterCity);
    }
    if (form.filterDateFrom) {
      filteredOrders = filteredOrders.filter(o => o.created_at >= form.filterDateFrom);
    }
    if (form.filterDateTo) {
      filteredOrders = filteredOrders.filter(o => o.created_at <= form.filterDateTo + "T23:59:59");
    }
    if (form.filterMinAmount) {
      filteredOrders = filteredOrders.filter(o => (o.total || 0) >= parseFloat(form.filterMinAmount));
    }
    if (form.filterMaxAmount) {
      filteredOrders = filteredOrders.filter(o => (o.total || 0) <= parseFloat(form.filterMaxAmount));
    }
    // Unique customer phones
    const phones = [...new Set(filteredOrders.map(o => o.customer_phone).filter(Boolean))];
    return customers.filter(c => phones.includes(c.phone));
  };

  const getAudienceCount = () => {
    if (form.audienceType === "upload") return uploadedRecipients.length;
    if (form.audienceType === "select") return selectedCustomerIds.length;
    if (form.audienceType === "orders") return getEcommerceFilteredCustomers().length;
    let filtered = customers;
    if (form.audienceType === "tags" && form.audienceTags.length > 0) {
      filtered = customers.filter((c) => (c.tags || []).some((t: string) => form.audienceTags.includes(t)));
    }
    if (form.excludeTags.length > 0) {
      filtered = filtered.filter((c) => !(c.tags || []).some((t: string) => form.excludeTags.includes(t)));
    }
    return filtered.length;
  };

  const buildRecipientList = (): Recipient[] => {
    if (form.audienceType === "upload") return uploadedRecipients;
    if (form.audienceType === "select") {
      return customers.filter((c) => selectedCustomerIds.includes(c.id)).map((c) => ({ phone: c.phone, name: c.name }));
    }
    if (form.audienceType === "orders") {
      return getEcommerceFilteredCustomers().map((c) => ({ phone: c.phone, name: c.name }));
    }
    let filtered = customers;
    if (form.audienceType === "tags" && form.audienceTags.length > 0) {
      filtered = customers.filter((c) => (c.tags || []).some((t: string) => form.audienceTags.includes(t)));
    }
    if (form.excludeTags.length > 0) {
      filtered = filtered.filter((c) => !(c.tags || []).some((t: string) => form.excludeTags.includes(t)));
    }
    return filtered.map((c) => ({ phone: c.phone, name: c.name }));
  };

  const selectedChannel = whatsappChannels.find((c) => c.id === form.channelId);
  const isEvolutionChannel = selectedChannel?.channel_type === "evolution";

  const getChannelLabel = (ch: any) => {
    if (ch.channel_type === "evolution") {
      return ch.evolution_instance_name ? `واتساب ويب — ${ch.evolution_instance_name}` : `واتساب ويب — ${ch.display_phone || "غير مسمى"}`;
    }
    return ch.display_phone ? `واتساب رسمي — ${ch.display_phone}` : `واتساب رسمي — ${ch.business_name || ch.phone_number_id}`;
  };

  const handleCreate = async () => {
    if (!form.name.trim()) { toast.error("يرجى كتابة اسم الحملة"); return; }
    if (!form.channelId) { toast.error("يرجى اختيار قناة الإرسال"); return; }
    if (isEvolutionChannel && !form.messageText.trim()) { toast.error("يرجى كتابة نص الرسالة"); return; }
    if (!isEvolutionChannel && !form.templateName.trim()) { toast.error("يرجى تحديد اسم القالب"); return; }
    const recipientList = buildRecipientList();
    if (recipientList.length === 0) { toast.error("لا يوجد مستلمين — اختر جمهوراً"); return; }

    const isRecurring = !!form.recurringType;
    const { data: campaign, error } = await supabase.from("campaigns").insert({
      org_id: orgId,
      name: form.name,
      template_name: isEvolutionChannel ? null : (form.templateName || null),
      template_language: form.templateLang,
      template_variables: isEvolutionChannel ? [{ message_text: form.messageText, delay_seconds: form.delaySeconds, channel_type: "evolution", channel_id: form.channelId }] : templateVars,
      audience_type: form.audienceType,
      audience_tags: form.audienceTags,
      exclude_tags: form.excludeTags,
      exclude_campaign_ids: form.excludeCampaignIds,
      status: isRecurring ? "scheduled" : (form.scheduledAt ? "scheduled" : "draft"),
      scheduled_at: form.scheduledAt || null,
      notes: form.notes || null,
      total_recipients: recipientList.length,
      recurring_type: form.recurringType || null,
      recurring_end_at: form.recurringEndAt || null,
    } as any).select().single();

    if (error) { toast.error("حدث خطأ في إنشاء الحملة"); return; }

    // Insert recipients in batches
    const batchSize = 500;
    for (let i = 0; i < recipientList.length; i += batchSize) {
      const batch = recipientList.slice(i, i + batchSize).map((r) => ({
        campaign_id: campaign.id,
        phone: r.phone,
        customer_name: r.name || null,
        variables: r.variables || {},
      }));
      await supabase.from("campaign_recipients").insert(batch as any);
    }

    toast.success(form.scheduledAt ? "تم جدولة الحملة بنجاح" : "تم حفظ الحملة كمسودة");
    resetForm();
    load();
  };

  const resetForm = () => {
    setShowCreate(false);
    setForm({ name: "", templateName: "", templateLang: "ar", scheduledAt: "", notes: "", audienceType: "all", audienceTags: [], excludeTags: [], excludeCampaignIds: [], variableColumns: [], channelId: "", messageText: "", delaySeconds: 10, recurringType: "", recurringEndAt: "", filterProduct: "", filterCity: "", filterDateFrom: "", filterDateTo: "", filterMinAmount: "", filterMaxAmount: "" });
    setUploadedRecipients([]);
    setSelectedCustomerIds([]);
    setTemplateVars([]);
  };

  const openDetail = async (campaign: any) => {
    setDetailCampaign(campaign);
    const { data } = await supabase.from("campaign_recipients").select("*").eq("campaign_id", campaign.id).order("created_at", { ascending: false }).limit(500);
    setRecipients(data || []);
  };

  const exportReport = () => {
    if (!detailCampaign || recipients.length === 0) return;
    const data = recipients.map((r) => ({
      "الرقم": r.phone,
      "الاسم": r.customer_name || "",
      "الحالة": r.status === "pending" ? "قيد الانتظار" : r.status === "sent" ? "أُرسلت" : r.status === "delivered" ? "تم التوصيل" : r.status === "read" ? "تمت القراءة" : r.status === "failed" ? "فشل" : r.status,
      "وقت الإرسال": r.sent_at ? new Date(r.sent_at).toLocaleString("ar-SA-u-ca-gregory") : "",
      "وقت التوصيل": r.delivered_at ? new Date(r.delivered_at).toLocaleString("ar-SA-u-ca-gregory") : "",
      "وقت القراءة": r.read_at ? new Date(r.read_at).toLocaleString("ar-SA-u-ca-gregory") : "",
      "كود الخطأ": r.error_code || "",
      "سبب الخطأ": r.error_message || "",
    }));
    const ws = XLSX.utils.json_to_sheet(data);
    ws["!cols"] = [{ wch: 16 }, { wch: 20 }, { wch: 14 }, { wch: 22 }, { wch: 22 }, { wch: 22 }, { wch: 14 }, { wch: 30 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "تقرير الحملة");
    XLSX.writeFile(wb, `حملة_${detailCampaign.name}_تقرير.xlsx`);
    toast.success("تم تصدير التقرير كملف Excel");
  };

  const downloadTemplate = () => {
    const selectedCh = whatsappChannels.find((c) => c.id === form.channelId);
    const isMeta = selectedCh?.channel_type !== "evolution";

    if (isMeta && templateVars.length > 0) {
      // Meta template with variables: phone + variable columns
      const headers = ["phone", ...templateVars.map((v) => v)];
      const sampleRow = ["966501234567", ...templateVars.map(() => "")];
      const ws = XLSX.utils.aoa_to_sheet([headers, sampleRow]);
      ws["!cols"] = headers.map(() => ({ wch: 20 }));
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "المستلمون");
      XLSX.writeFile(wb, `قالب_حملة_${form.templateName || "campaign"}.xlsx`);
    } else if (!isMeta) {
      // Evolution: phone + name + dynamic variable columns extracted from message
      const placeholders = (form.messageText.match(/\{(\w+)\}/g) || []).map((p) => p.replace(/[{}]/g, "")).filter((p) => p !== "name");
      const headers = ["phone", "name", ...placeholders];
      const sampleRow = ["966501234567", "أحمد", ...placeholders.map(() => "")];
      const ws = XLSX.utils.aoa_to_sheet([headers, sampleRow]);
      ws["!cols"] = headers.map(() => ({ wch: 20 }));
      // Add note about placeholders
      if (placeholders.length > 0) {
        const noteWs = XLSX.utils.aoa_to_sheet([
          ["متغيرات الرسالة"],
          ["استخدم {name} لاسم العميل في نص الرسالة"],
          ...placeholders.map((p) => [`استخدم {${p}} — العمود "${p}" في الإكسل`]),
        ]);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "المستلمون");
        XLSX.utils.book_append_sheet(wb, noteWs, "تعليمات");
        XLSX.writeFile(wb, "قالب_حملة_واتساب.xlsx");
      } else {
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "المستلمون");
        XLSX.writeFile(wb, "قالب_حملة_واتساب.xlsx");
      }
    } else {
      // Meta without variables: just phone
      const ws = XLSX.utils.aoa_to_sheet([["phone"], ["966501234567"]]);
      ws["!cols"] = [{ wch: 20 }];
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "المستلمون");
      XLSX.writeFile(wb, "قالب_حملة.xlsx");
    }
    toast.success("تم تنزيل ملف القالب");
  };

  const resendFailed = async () => {
    if (!detailCampaign) return;
    const failedRecipients = recipients.filter((r) => r.status === "failed");
    if (failedRecipients.length === 0) { toast.error("لا توجد رسائل فاشلة"); return; }

    // Check 24h cooldown
    const sentAt = detailCampaign.sent_at ? new Date(detailCampaign.sent_at) : null;
    if (sentAt) {
      const hoursSince = (Date.now() - sentAt.getTime()) / (1000 * 60 * 60);
      if (hoursSince < 24) {
        toast.error(`يرجى الانتظار ${Math.ceil(24 - hoursSince)} ساعة قبل إعادة الإرسال`);
        return;
      }
    }

    // Reset failed recipients to pending
    const failedIds = failedRecipients.map((r) => r.id);
    for (let i = 0; i < failedIds.length; i += 50) {
      const batch = failedIds.slice(i, i + 50);
      await supabase.from("campaign_recipients").update({
        status: "pending",
        error_code: null,
        error_message: null,
        failed_at: null,
      } as any).in("id", batch);
    }

    // Trigger send
    const { error } = await invokeCloud("send-campaign", {
      body: { campaign_id: detailCampaign.id },
    });
    if (error) {
      toast.error("فشل إعادة الإرسال: " + error.message);
    } else {
      toast.success(`بدأ إعادة إرسال ${failedRecipients.length} رسالة فاشلة`);
      setDetailCampaign(null);
      load();
    }
  };

  const toggleTag = (tag: string, field: "audienceTags" | "excludeTags") => {
    setForm((f) => ({
      ...f,
      [field]: f[field].includes(tag) ? f[field].filter((t) => t !== tag) : [...f[field], tag],
    }));
  };

  const toggleCustomer = (id: string) => {
    setSelectedCustomerIds((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]);
  };

  const filtered = campaigns.filter((c) => {
    if (searchQuery && !c.name?.includes(searchQuery)) return false;
    if (statusFilter !== "all" && c.status !== statusFilter) return false;
    return true;
  });

  const totalSent = campaigns.reduce((s, c) => s + (c.sent_count || 0), 0);
  const totalDelivered = campaigns.reduce((s, c) => s + (c.delivered_count || 0), 0);

  const recipientStatusBadge = (status: string) => {
    const map: Record<string, string> = {
      pending: "bg-muted text-muted-foreground",
      sent: "bg-info/10 text-info",
      delivered: "bg-success/10 text-success",
      read: "bg-primary/10 text-primary",
      failed: "bg-destructive/10 text-destructive",
    };
    const labels: Record<string, string> = { pending: "قيد الانتظار", sent: "أُرسلت", delivered: "تم التوصيل", read: "تمت القراءة", failed: "فشل" };
    return <Badge className={cn("text-[9px] border-0", map[status] || map.pending)}>{labels[status] || status}</Badge>;
  };

  return (
    <div className="p-3 md:p-6 space-y-6 max-w-[1000px] mx-auto" dir="rtl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold">الحملات</h1>
          <p className="text-sm text-muted-foreground mt-1">إدارة حملات WhatsApp وتتبع نتائجها</p>
        </div>
        <div className="flex items-center gap-2">
          {compareMode ? (
            <>
              <Button variant="outline" size="sm" className="gap-2 text-xs" onClick={() => { setCompareMode(false); setCompareIds([]); }}>
                <X className="w-3 h-3" /> إلغاء
              </Button>
              <Button size="sm" className="gap-2 text-xs" disabled={compareIds.length !== 2} onClick={() => setShowCompare(true)}>
                <GitCompareArrows className="w-3 h-3" /> مقارنة ({compareIds.length}/2)
              </Button>
            </>
          ) : (
            <>
              <Button variant="outline" className="gap-2 text-xs" onClick={() => setCompareMode(true)}>
                <GitCompareArrows className="w-4 h-4" /> مقارنة
              </Button>
              <Button className="gap-2 gradient-whatsapp text-whatsapp-foreground" onClick={() => setShowCreate(true)}>
                <Plus className="w-4 h-4" /> حملة جديدة
              </Button>
            </>
          )}
        </div>
      </div>

      {/* Analytics Dashboard */}
      {(() => {
        const totalRead = campaigns.reduce((s, c) => s + (c.read_count || 0), 0);
        const totalFailed = campaigns.reduce((s, c) => s + (c.failed_count || 0), 0);
        const totalRecipients = campaigns.reduce((s, c) => s + (c.total_recipients || 0), 0);
        const deliveryRate = totalSent > 0 ? Math.round((totalDelivered / totalSent) * 100) : 0;
        const readRate = totalDelivered > 0 ? Math.round((totalRead / totalDelivered) * 100) : 0;
        const failRate = totalRecipients > 0 ? Math.round((totalFailed / totalRecipients) * 100) : 0;

        // Build monthly time series from campaigns
        const monthlyMap: Record<string, { month: string; sent: number; delivered: number; read: number; failed: number; campaigns: number }> = {};
        campaigns.forEach((c) => {
          const d = c.sent_at || c.created_at;
          if (!d) return;
          const key = d.slice(0, 7); // YYYY-MM
          if (!monthlyMap[key]) monthlyMap[key] = { month: key, sent: 0, delivered: 0, read: 0, failed: 0, campaigns: 0 };
          monthlyMap[key].sent += c.sent_count || 0;
          monthlyMap[key].delivered += c.delivered_count || 0;
          monthlyMap[key].read += c.read_count || 0;
          monthlyMap[key].failed += c.failed_count || 0;
          monthlyMap[key].campaigns += 1;
        });
        const timeData = Object.values(monthlyMap).sort((a, b) => a.month.localeCompare(b.month)).map((m) => ({
          ...m,
          label: new Date(m.month + "-01").toLocaleDateString("ar-SA-u-ca-gregory", { month: "short", year: "2-digit" }),
        }));

        // Pie data for status distribution
        const statusDist = [
          { name: "مسودة", value: campaigns.filter((c) => c.status === "draft").length, color: "hsl(var(--muted-foreground))" },
          { name: "مجدولة", value: campaigns.filter((c) => c.status === "scheduled").length, color: "hsl(var(--info))" },
          { name: "في الطابور", value: campaigns.filter((c) => c.status === "queued").length, color: "hsl(var(--info))" },
          { name: "تم الإرسال", value: campaigns.filter((c) => c.status === "sent").length, color: "hsl(var(--success))" },
          { name: "جاري الإرسال", value: campaigns.filter((c) => ["sending", "paused"].includes(c.status)).length, color: "hsl(var(--warning))" },
          { name: "فشل", value: campaigns.filter((c) => c.status === "failed").length, color: "hsl(var(--destructive))" },
        ].filter((d) => d.value > 0);

        return (
          <div className="space-y-4">
            {/* KPI Cards */}
            <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
              {[
                { label: "إجمالي الحملات", value: campaigns.length, color: "" },
                { label: "تم إرسالها", value: campaigns.filter((c) => c.status === "sent").length, color: "text-success" },
                { label: "رسائل مرسلة", value: totalSent.toLocaleString(), color: "text-info" },
                { label: "معدل التوصيل", value: `${deliveryRate}%`, color: "text-primary" },
                { label: "معدل القراءة", value: `${readRate}%`, color: "text-primary" },
                { label: "معدل الفشل", value: `${failRate}%`, color: "text-destructive" },
              ].map((kpi) => (
                <div key={kpi.label} className="bg-card rounded-lg p-3 shadow-card text-center">
                  <p className={cn("text-xl font-bold", kpi.color)}>{kpi.value}</p>
                  <p className="text-[10px] text-muted-foreground">{kpi.label}</p>
                </div>
              ))}
            </div>

            {/* Charts Row */}
            {timeData.length > 0 && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                {/* Line Chart - Performance Over Time */}
                <div className="lg:col-span-2 bg-card rounded-xl shadow-card p-4">
                  <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-primary" /> أداء الحملات عبر الزمن
                  </h3>
                  <ResponsiveContainer width="100%" height={220}>
                    <LineChart data={timeData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis dataKey="label" tick={{ fontSize: 10 }} stroke="hsl(var(--muted-foreground))" />
                      <YAxis tick={{ fontSize: 10 }} stroke="hsl(var(--muted-foreground))" />
                      <Tooltip
                        contentStyle={{ backgroundColor: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }}
                        labelStyle={{ fontWeight: 600 }}
                      />
                      <Line type="monotone" dataKey="sent" stroke="hsl(var(--info))" strokeWidth={2} name="مُرسلة" dot={{ r: 3 }} />
                      <Line type="monotone" dataKey="delivered" stroke="hsl(var(--success))" strokeWidth={2} name="تم التوصيل" dot={{ r: 3 }} />
                      <Line type="monotone" dataKey="read" stroke="hsl(var(--primary))" strokeWidth={2} name="تمت القراءة" dot={{ r: 3 }} />
                      <Line type="monotone" dataKey="failed" stroke="hsl(var(--destructive))" strokeWidth={2} name="فشل" dot={{ r: 3 }} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>

                {/* Pie Chart - Status Distribution */}
                <div className="bg-card rounded-xl shadow-card p-4">
                  <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                    <BarChart3 className="w-4 h-4 text-primary" /> توزيع الحالات
                  </h3>
                  <ResponsiveContainer width="100%" height={220}>
                    <PieChart>
                      <Pie data={statusDist} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={45} outerRadius={75} paddingAngle={3}>
                        {statusDist.map((entry, i) => (
                          <Cell key={i} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip contentStyle={{ backgroundColor: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }} />
                      <Legend wrapperStyle={{ fontSize: 11 }} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>
            )}

            {/* Bar Chart - Campaigns per Month */}
            {timeData.length > 1 && (
              <div className="bg-card rounded-xl shadow-card p-4">
                <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                  <Megaphone className="w-4 h-4 text-primary" /> عدد الحملات والرسائل شهرياً
                </h3>
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={timeData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="label" tick={{ fontSize: 10 }} stroke="hsl(var(--muted-foreground))" />
                    <YAxis tick={{ fontSize: 10 }} stroke="hsl(var(--muted-foreground))" />
                    <Tooltip contentStyle={{ backgroundColor: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }} />
                    <Bar dataKey="sent" fill="hsl(var(--info))" name="مُرسلة" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="delivered" fill="hsl(var(--success))" name="تم التوصيل" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="read" fill="hsl(var(--primary))" name="تمت القراءة" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>
        );
      })()}

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[180px] max-w-sm">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="بحث في الحملات..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pr-9 bg-secondary border-0 text-sm" />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[130px] text-xs bg-secondary border-0"><SelectValue placeholder="الحالة" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">كل الحالات</SelectItem>
            <SelectItem value="draft">مسودة</SelectItem>
            <SelectItem value="scheduled">مجدولة</SelectItem>
            <SelectItem value="sending">جاري الإرسال</SelectItem>
            <SelectItem value="sent">تم الإرسال</SelectItem>
            <SelectItem value="failed">فشل</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Campaigns List */}
      <div className="space-y-3">
        {filtered.map((campaign) => {
          const status = statusConfig[campaign.status] || statusConfig.draft;
          const deliveryRate = campaign.sent_count > 0 ? Math.round((campaign.delivered_count / campaign.sent_count) * 100) : 0;
          return (
            <div
              key={campaign.id}
              className={cn(
                "bg-card rounded-lg p-5 shadow-card hover:shadow-card-hover transition-shadow cursor-pointer",
                compareMode && compareIds.includes(campaign.id) && "ring-2 ring-primary"
              )}
              onClick={() => {
                if (compareMode) {
                  setCompareIds((prev) =>
                    prev.includes(campaign.id) ? prev.filter((x) => x !== campaign.id) : prev.length < 2 ? [...prev, campaign.id] : prev
                  );
                } else {
                  openDetail(campaign);
                }
              }}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                    <Megaphone className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-semibold">{campaign.name}</h3>
                    <p className="text-xs text-muted-foreground">
                      {campaign.sent_at ? `أُرسلت: ${new Date(campaign.sent_at).toLocaleDateString("ar-SA-u-ca-gregory")}` : campaign.scheduled_at ? `مجدولة: ${new Date(campaign.scheduled_at).toLocaleDateString("ar-SA-u-ca-gregory")}` : `أُنشئت: ${new Date(campaign.created_at).toLocaleDateString("ar-SA-u-ca-gregory")}`}
                      {campaign.template_name && <span className="mr-2">• قالب: {campaign.template_name}</span>}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {campaign.recurring_type && (
                    <Badge className="border-0 text-[9px] bg-primary/10 text-primary gap-0.5">
                      <Repeat className="w-2.5 h-2.5" />
                      {campaign.recurring_type === "daily" ? "يومي" : campaign.recurring_type === "weekly" ? "أسبوعي" : "شهري"}
                      {campaign.recurring_count > 0 && <span>({campaign.recurring_count})</span>}
                    </Badge>
                  )}
                  <Badge className={cn("border-0 text-xs", status.className)}>
                    <status.icon className="w-3 h-3 ml-1" />
                    {status.label}
                  </Badge>
                  <ArrowRight className="w-4 h-4 text-muted-foreground" />
                </div>
              </div>
              <div className="grid grid-cols-5 gap-3 text-center">
                <div><p className="text-lg font-bold">{(campaign.total_recipients || 0).toLocaleString()}</p><p className="text-[10px] text-muted-foreground">الجمهور</p></div>
                <div><p className="text-lg font-bold">{(campaign.sent_count || 0).toLocaleString()}</p><p className="text-[10px] text-muted-foreground">مُرسلة</p></div>
                <div><p className="text-lg font-bold">{(campaign.delivered_count || 0).toLocaleString()}</p><p className="text-[10px] text-muted-foreground">تم التوصيل</p></div>
                <div><p className="text-lg font-bold text-primary">{(campaign.read_count || 0).toLocaleString()}</p><p className="text-[10px] text-muted-foreground">تمت القراءة</p></div>
                <div><p className="text-lg font-bold text-destructive">{(campaign.failed_count || 0).toLocaleString()}</p><p className="text-[10px] text-muted-foreground">فشل</p></div>
              </div>
              {campaign.sent_count > 0 && (
                <div className="mt-3">
                  <div className="flex justify-between text-[10px] text-muted-foreground mb-1">
                    <span>معدل التوصيل</span><span>{deliveryRate}%</span>
                  </div>
                  <Progress value={deliveryRate} className="h-1.5" />
                </div>
              )}
            </div>
          );
        })}
        {filtered.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            <Megaphone className="w-10 h-10 mx-auto mb-3 opacity-30" />
            <p className="text-sm">لا توجد حملات — أنشئ حملتك الأولى</p>
          </div>
        )}
      </div>

      {/* Create Campaign Dialog */}
      <Dialog open={showCreate} onOpenChange={(v) => { if (!v) resetForm(); else setShowCreate(true); }}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto" dir="rtl">
          <DialogHeader><DialogTitle>إنشاء حملة جديدة</DialogTitle></DialogHeader>
          <div className="space-y-5 mt-2">
            <CampaignSafetyTips />
            {/* Name */}
            <div className="space-y-1.5">
              <Label className="text-xs">اسم الحملة *</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="مثال: عروض الصيف" className="text-sm bg-secondary border-0" />
            </div>

            {/* Channel Selection */}
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold">قناة الإرسال *</Label>
              {whatsappChannels.length === 0 ? (
                <div className="bg-destructive/10 text-destructive rounded-lg p-3 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  لا توجد قنوات واتساب مربوطة — اذهب لصفحة الربط والتكامل أولاً
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {whatsappChannels.map((ch) => (
                    <button
                      key={ch.id}
                      onClick={() => setForm({ ...form, channelId: ch.id })}
                      className={cn(
                        "p-3 rounded-lg border text-xs text-right transition-all",
                        form.channelId === ch.id ? "border-primary bg-primary/5 text-primary" : "border-border hover:border-primary/50"
                      )}
                    >
                      <div className="flex items-center gap-2">
                        {ch.channel_type === "evolution" ? (
                          <MessageSquare className="w-4 h-4 shrink-0" />
                        ) : (
                          <Shield className="w-4 h-4 shrink-0" />
                        )}
                        <span className="font-medium">{getChannelLabel(ch)}</span>
                      </div>
                      <p className="text-[10px] text-muted-foreground mt-1">
                        {ch.channel_type === "evolution" ? "رسائل نصية مباشرة" : "قوالب Meta معتمدة"}
                      </p>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Evolution Warning */}
            {isEvolutionChannel && (
              <div className="bg-warning/10 border border-warning/30 rounded-lg p-3 space-y-2">
                <div className="flex items-start gap-2 text-warning">
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                  <div className="text-xs space-y-1">
                    <p className="font-semibold">تحذير — قناة غير رسمية</p>
                    <p className="text-muted-foreground">إرسال عدد كبير من الرسائل بسرعة قد يؤدي لحظر الرقم. استخدم تأخيراً مناسباً بين الرسائل ولا ترسل لأرقام لم تتواصل معك سابقاً.</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3 mt-2">
                  <div className="space-y-1">
                    <Label className="text-[10px] text-muted-foreground">التأخير بين كل رسالة (ثانية) *</Label>
                    <Input
                      type="number"
                      min={5}
                      max={3600}
                      value={form.delaySeconds}
                      onChange={(e) => setForm({ ...form, delaySeconds: Math.max(5, parseInt(e.target.value) || 10) })}
                      className="text-xs bg-background border-0 h-8"
                      dir="ltr"
                    />
                  </div>
                  <div className="flex flex-col justify-end">
                    <p className="text-[10px] text-muted-foreground">
                      الوقت المتوقع: <strong className="text-foreground">{Math.ceil((getAudienceCount() * form.delaySeconds) / 60)} دقيقة</strong>
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Message Text (Evolution only) */}
            {isEvolutionChannel && (
              <div className="space-y-1.5">
                <Label className="text-xs">نص الرسالة *</Label>
                <Textarea
                  value={form.messageText}
                  onChange={(e) => setForm({ ...form, messageText: e.target.value })}
                  placeholder={"مرحباً {name}، عرض خاص لك! الخصم {discount}"}
                  className="text-sm bg-secondary border-0 min-h-[80px]"
                />
                <p className="text-[10px] text-muted-foreground">
                  💡 استخدم <code className="bg-secondary px-1 rounded">{"{name}"}</code> لاسم العميل. يمكنك إضافة متغيرات مخصصة مثل <code className="bg-secondary px-1 rounded">{"{discount}"}</code> — عند رفع الإكسل أضف عمود بنفس الاسم
                </p>
              </div>
            )}

            {/* Template (Meta API only) */}
            {!isEvolutionChannel && form.channelId && (
              <>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label className="text-xs">اسم القالب (من Meta) *</Label>
                    <Input value={form.templateName} onChange={(e) => setForm({ ...form, templateName: e.target.value })} placeholder="مثال: summer_offer" className="text-sm bg-secondary border-0" dir="ltr" />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">لغة القالب</Label>
                    <Select value={form.templateLang} onValueChange={(v) => setForm({ ...form, templateLang: v })}>
                      <SelectTrigger className="text-sm bg-secondary border-0"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ar">العربية</SelectItem>
                        <SelectItem value="en">English</SelectItem>
                        <SelectItem value="en_US">English (US)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </>
            )}

            {/* Template Variables (Meta only) */}
            {!isEvolutionChannel && form.channelId && (
            <div className="space-y-1.5">
              <Label className="text-xs">متغيرات القالب (اختياري)</Label>
              <p className="text-[10px] text-muted-foreground">أضف أسماء المتغيرات بالترتيب مثل: الاسم، رقم_الطلب — يمكنك تعبئتها من الإكسل</p>
              <div className="flex flex-wrap gap-2">
                {templateVars.map((v, i) => (
                  <div key={i} className="flex items-center gap-1 bg-secondary rounded-full px-2.5 py-1 text-xs">
                    <span className="text-muted-foreground">{`{{${i + 1}}}`}</span>
                    <span>{v}</span>
                    <button onClick={() => setTemplateVars((prev) => prev.filter((_, j) => j !== i))}>
                      <X className="w-3 h-3 text-muted-foreground hover:text-destructive" />
                    </button>
                  </div>
                ))}
                <Input
                  placeholder="أضف متغير + Enter"
                  className="w-36 h-7 text-xs bg-secondary border-0"
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && (e.target as HTMLInputElement).value.trim()) {
                      setTemplateVars((prev) => [...prev, (e.target as HTMLInputElement).value.trim()]);
                      (e.target as HTMLInputElement).value = "";
                    }
                  }}
                />
              </div>
            </div>
            )}

            {/* Meta Cost Estimator */}
            {!isEvolutionChannel && form.channelId && getAudienceCount() > 0 && (
              <div className="bg-info/5 border border-info/20 rounded-lg p-4 space-y-2">
                <div className="flex items-start gap-2">
                  <BarChart3 className="w-4 h-4 text-info shrink-0 mt-0.5" />
                  <div className="flex-1 space-y-2">
                    <p className="text-xs font-semibold text-info">التكلفة التقديرية لهذه الحملة</p>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      {(() => {
                        const count = getAudienceCount();
                        // Meta per-message pricing (2026) - Saudi Arabia
                        // Marketing: ~0.35 SAR, Utility: ~0.15 SAR, Auth: ~0.20 SAR
                        // Service (customer-initiated): FREE
                        const marketingRate = 0.35; // SAR
                        const utilityRate = 0.15; // SAR
                        const authRate = 0.20; // SAR
                        const marketingCost = (count * marketingRate).toFixed(2);
                        const utilityCost = (count * utilityRate).toFixed(2);
                        return (
                          <>
                            <div className="bg-background rounded-lg p-2.5 text-center border">
                              <p className="text-[10px] text-muted-foreground">عدد المستلمين</p>
                              <p className="text-sm font-bold mt-0.5">{count.toLocaleString()}</p>
                            </div>
                            <div className="bg-background rounded-lg p-2.5 text-center border">
                              <p className="text-[10px] text-muted-foreground">تسويقية (Marketing)</p>
                              <p className="text-sm font-bold mt-0.5 text-warning">~{marketingCost} ر.س</p>
                              <p className="text-[9px] text-muted-foreground">{marketingRate} ر.س/رسالة</p>
                            </div>
                            <div className="bg-background rounded-lg p-2.5 text-center border">
                              <p className="text-[10px] text-muted-foreground">خدمية (Utility)</p>
                              <p className="text-sm font-bold mt-0.5 text-primary">~{utilityCost} ر.س</p>
                              <p className="text-[9px] text-muted-foreground">{utilityRate} ر.س/رسالة</p>
                            </div>
                            <div className="bg-background rounded-lg p-2.5 text-center border">
                              <p className="text-[10px] text-muted-foreground">مصادقة (Auth)</p>
                              <p className="text-sm font-bold mt-0.5">{(count * authRate).toFixed(2)} ر.س</p>
                              <p className="text-[9px] text-muted-foreground">{authRate} ر.س/رسالة</p>
                            </div>
                          </>
                        );
                      })()}
                    </div>
                    <div className="bg-warning/10 rounded-md px-3 py-2 mt-1">
                      <p className="text-[10px] text-muted-foreground leading-relaxed">
                        ⚠️ <strong>هذه أسعار تقريبية</strong> — التكلفة الفعلية تُخصم مباشرة من حسابك في Meta وتعتمد على فئة القالب (تسويقي / خدمي / مصادقة) والمنطقة الجغرافية للمستلم. <strong>منصة Respondly لا تتحكم في هذه الرسوم ولا تحصّلها.</strong>
                      </p>
                      <div className="flex items-center gap-2 mt-2">
                        <a
                          href="https://developers.facebook.com/docs/whatsapp/pricing"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-[10px] text-primary hover:underline flex items-center gap-1"
                        >
                          📄 تسعيرة Meta الرسمية
                          <ExternalLink className="w-3 h-3" />
                        </a>
                        <span className="text-muted-foreground text-[10px]">|</span>
                        <button
                          type="button"
                          onClick={() => window.open("https://developers.facebook.com/docs/whatsapp/pricing", "_blank")}
                          className="text-[10px] text-primary hover:underline flex items-center gap-1"
                        >
                          💰 صفحة الأسعار التفصيلية
                          <ExternalLink className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Audience */}
            <div className="space-y-3">
              <Label className="text-xs font-semibold">الجمهور المستهدف</Label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {[
                  { value: "all", label: "كل العملاء", icon: Users },
                  { value: "tags", label: "حسب التصنيف", icon: Target },
                  { value: "select", label: "اختيار يدوي", icon: Check },
                  { value: "upload", label: "رفع إكسل", icon: Upload },
                  ...(isEcommerce ? [{ value: "orders", label: "حسب الطلبات", icon: ShoppingCart }] : []),
                ].map((opt) => (
                  <button
                    key={opt.value}
                    onClick={() => setForm({ ...form, audienceType: opt.value })}
                    className={cn(
                      "p-3 rounded-lg border text-xs flex flex-col items-center gap-1.5 transition-all",
                      form.audienceType === opt.value ? "border-primary bg-primary/5 text-primary" : "border-border hover:border-primary/50"
                    )}
                  >
                    <opt.icon className="w-4 h-4" />
                    {opt.label}
                  </button>
                ))}
              </div>

              {/* Tags Selection */}
              {form.audienceType === "tags" && (
                <div className="space-y-2">
                  <Label className="text-[10px] text-muted-foreground">اختر التصنيفات المستهدفة:</Label>
                  <div className="flex flex-wrap gap-1.5">
                    {tagDefs.map((t) => (
                      <button
                        key={t.id}
                        onClick={() => toggleTag(t.name, "audienceTags")}
                        className={cn("text-[10px] px-2.5 py-1 rounded-full border transition-colors", form.audienceTags.includes(t.name) ? "bg-primary text-primary-foreground border-primary" : "bg-secondary border-border")}
                      >
                        {t.name}
                      </button>
                    ))}
                    {tagDefs.length === 0 && <span className="text-[10px] text-muted-foreground">لا توجد تصنيفات — أضفها من إعدادات العملاء</span>}
                  </div>
                </div>
              )}

              {/* Manual Selection */}
              {form.audienceType === "select" && (
                <div className="space-y-2 max-h-48 overflow-y-auto border border-border rounded-lg p-2">
                  {customers.map((c) => (
                    <label key={c.id} className="flex items-center gap-2 p-1.5 hover:bg-secondary/50 rounded cursor-pointer">
                      <Checkbox checked={selectedCustomerIds.includes(c.id)} onCheckedChange={() => toggleCustomer(c.id)} />
                      <span className="text-xs">{c.name || c.phone}</span>
                      <span className="text-[10px] text-muted-foreground mr-auto" dir="ltr">{c.phone}</span>
                    </label>
                  ))}
                  {customers.length === 0 && <p className="text-[10px] text-muted-foreground text-center py-3">لا يوجد عملاء</p>}
                </div>
              )}

              {/* Upload */}
              {form.audienceType === "upload" && (
                <div className="space-y-2">
                  <div className="border-2 border-dashed border-border rounded-lg p-4 text-center">
                    <Upload className="w-6 h-6 mx-auto text-muted-foreground mb-2" />
                    <p className="text-xs text-muted-foreground mb-1">ارفع ملف Excel يحتوي على الأرقام</p>
                    <p className="text-[10px] text-muted-foreground mb-3">العمود الأول: phone (رقم الجوال) — الأعمدة الإضافية تُستخدم كمتغيرات للقالب</p>
                    <div className="flex items-center justify-center gap-2">
                      <Button size="sm" variant="outline" className="text-xs" onClick={() => fileRef.current?.click()}>
                        <Upload className="w-3 h-3 ml-1" /> رفع ملف
                      </Button>
                      {form.channelId && (
                        <Button size="sm" variant="ghost" className="text-xs text-primary" onClick={downloadTemplate}>
                          <Download className="w-3 h-3 ml-1" /> تنزيل القالب
                        </Button>
                      )}
                    </div>
                    <input ref={fileRef} type="file" accept=".csv,.xlsx" className="hidden" onChange={handleFileUpload} />
                  </div>
                  {!form.channelId && (
                    <p className="text-[10px] text-warning text-center">⚠️ اختر قناة الإرسال أولاً لتنزيل قالب مناسب</p>
                  )}
                  {uploadedRecipients.length > 0 && (
                    <div className="bg-success/5 rounded-lg p-3 flex items-center justify-between">
                      <span className="text-xs text-success font-medium">✅ تم تحميل {uploadedRecipients.length} رقم</span>
                      {form.variableColumns.length > 0 && (
                        <span className="text-[10px] text-muted-foreground">متغيرات: {form.variableColumns.join("، ")}</span>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* E-commerce Orders Filter */}
              {form.audienceType === "orders" && isEcommerce && (
                <div className="space-y-3 bg-secondary/30 rounded-xl p-4">
                  <p className="text-xs font-semibold flex items-center gap-1.5"><ShoppingCart className="w-3.5 h-3.5 text-primary" /> فلاتر الطلبات المتقدمة</p>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <Label className="text-[10px] text-muted-foreground">المنتج</Label>
                      <Select value={form.filterProduct} onValueChange={(v) => setForm({ ...form, filterProduct: v === "_all" ? "" : v })}>
                        <SelectTrigger className="text-xs bg-background border-0 h-8"><SelectValue placeholder="كل المنتجات" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="_all">كل المنتجات</SelectItem>
                          {products.map(p => <SelectItem key={p.id} value={p.name}>{p.name_ar || p.name}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-1">
                      <Label className="text-[10px] text-muted-foreground">المدينة</Label>
                      <Select value={form.filterCity} onValueChange={(v) => setForm({ ...form, filterCity: v === "_all" ? "" : v })}>
                        <SelectTrigger className="text-xs bg-background border-0 h-8"><SelectValue placeholder="كل المدن" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="_all">كل المدن</SelectItem>
                          {[...new Set(orders.map(o => o.customer_city).filter(Boolean))].map(city => (
                            <SelectItem key={city} value={city}>{city}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-1">
                      <Label className="text-[10px] text-muted-foreground">من تاريخ</Label>
                      <Input type="date" value={form.filterDateFrom} onChange={(e) => setForm({ ...form, filterDateFrom: e.target.value })} className="text-xs bg-background border-0 h-8" dir="ltr" />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-[10px] text-muted-foreground">إلى تاريخ</Label>
                      <Input type="date" value={form.filterDateTo} onChange={(e) => setForm({ ...form, filterDateTo: e.target.value })} className="text-xs bg-background border-0 h-8" dir="ltr" />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-[10px] text-muted-foreground">الحد الأدنى للمبلغ</Label>
                      <Input type="number" value={form.filterMinAmount} onChange={(e) => setForm({ ...form, filterMinAmount: e.target.value })} placeholder="0" className="text-xs bg-background border-0 h-8" dir="ltr" />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-[10px] text-muted-foreground">الحد الأقصى للمبلغ</Label>
                      <Input type="number" value={form.filterMaxAmount} onChange={(e) => setForm({ ...form, filterMaxAmount: e.target.value })} placeholder="∞" className="text-xs bg-background border-0 h-8" dir="ltr" />
                    </div>
                  </div>
                  <div className="bg-primary/5 rounded-lg p-2.5 text-xs text-primary font-medium">
                    عملاء مطابقون: {getEcommerceFilteredCustomers().length}
                  </div>
                </div>
              )}
            </div>

            {/* Exclusions */}
            <div className="space-y-2">
              <Label className="text-xs font-semibold flex items-center gap-1"><Ban className="w-3 h-3" /> استثناءات (اختياري)</Label>
              <div className="space-y-2">
                <div>
                  <Label className="text-[10px] text-muted-foreground">استثناء حسب التصنيف:</Label>
                  <div className="flex flex-wrap gap-1.5 mt-1">
                    {tagDefs.map((t) => (
                      <button
                        key={t.id}
                        onClick={() => toggleTag(t.name, "excludeTags")}
                        className={cn("text-[10px] px-2.5 py-1 rounded-full border transition-colors", form.excludeTags.includes(t.name) ? "bg-destructive/10 text-destructive border-destructive" : "bg-secondary border-border")}
                      >
                        {t.name}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <Label className="text-[10px] text-muted-foreground">استثناء من أُرسل لهم في حملة سابقة:</Label>
                  <div className="flex flex-wrap gap-1.5 mt-1">
                    {campaigns.filter((c) => c.status === "sent").map((c) => (
                      <button
                        key={c.id}
                        onClick={() => setForm((f) => ({ ...f, excludeCampaignIds: f.excludeCampaignIds.includes(c.id) ? f.excludeCampaignIds.filter((x) => x !== c.id) : [...f.excludeCampaignIds, c.id] }))}
                        className={cn("text-[10px] px-2.5 py-1 rounded-full border transition-colors", form.excludeCampaignIds.includes(c.id) ? "bg-destructive/10 text-destructive border-destructive" : "bg-secondary border-border")}
                      >
                        {c.name}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Recurring */}
            <div className="space-y-2">
              <Label className="text-xs font-semibold flex items-center gap-1"><Repeat className="w-3 h-3" /> تكرار الحملة (اختياري)</Label>
              <div className="grid grid-cols-5 gap-1.5">
                {[
                  { value: "", label: "مرة واحدة" },
                  { value: "daily", label: "يومي" },
                  { value: "weekly", label: "أسبوعي" },
                  { value: "monthly", label: "شهري" },
                ].map(opt => (
                  <button
                    key={opt.value}
                    onClick={() => setForm({ ...form, recurringType: opt.value })}
                    className={cn(
                      "text-[10px] py-1.5 px-2 rounded-lg border transition-all",
                      form.recurringType === opt.value ? "border-primary bg-primary/5 text-primary font-medium" : "border-border hover:border-primary/50"
                    )}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
              {form.recurringType && (
                <div className="space-y-1.5">
                  <Label className="text-[10px] text-muted-foreground">ينتهي التكرار في (اختياري):</Label>
                  <Input type="date" value={form.recurringEndAt} onChange={(e) => setForm({ ...form, recurringEndAt: e.target.value })} className="text-sm bg-secondary border-0" dir="ltr" />
                  <p className="text-[10px] text-muted-foreground">
                    {form.recurringType === "daily" && "سيتم إعادة إرسال الحملة يومياً لنفس الجمهور"}
                    {form.recurringType === "weekly" && "سيتم إعادة إرسال الحملة كل أسبوع في نفس اليوم"}
                    {form.recurringType === "monthly" && "سيتم إعادة إرسال الحملة كل شهر في نفس التاريخ"}
                  </p>
                </div>
              )}
            </div>

            {/* Schedule */}
            <div className="space-y-1.5">
              <Label className="text-xs">جدولة الإرسال {form.recurringType ? "(موعد أول إرسال)" : "(اختياري)"}</Label>
              <Input type="datetime-local" value={form.scheduledAt} onChange={(e) => setForm({ ...form, scheduledAt: e.target.value })} className="text-sm bg-secondary border-0" dir="ltr" />
            </div>

            {/* A/B Testing */}
            {!isEvolutionChannel && (
              <div className="border rounded-lg p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <GitCompareArrows className="w-4 h-4 text-primary" />
                    <Label className="text-xs font-medium">اختبار A/B</Label>
                  </div>
                  <Badge variant="outline" className="text-[10px]">قريباً</Badge>
                </div>
                <p className="text-[10px] text-muted-foreground">أرسل نسختين من الرسالة لمجموعتين مختلفة واكتشف أيهما أفضل أداءً</p>
              </div>
            )}

            {/* Notes */}
            <div className="space-y-1.5">
              <Label className="text-xs">ملاحظات</Label>
              <Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="ملاحظات داخلية..." className="text-sm bg-secondary border-0 min-h-[50px]" />
            </div>

            {/* Summary & Submit */}
            <div className="bg-secondary/50 rounded-lg p-3 flex items-center justify-between">
              <span className="text-xs font-medium">عدد المستلمين: <strong className="text-primary">{getAudienceCount().toLocaleString()}</strong></span>
              {form.excludeTags.length > 0 && <span className="text-[10px] text-muted-foreground">بعد الاستثناءات</span>}
            </div>

            <Button onClick={handleCreate} className="w-full gradient-whatsapp text-whatsapp-foreground gap-1">
              {form.recurringType ? <><Repeat className="w-4 h-4" /> إنشاء حملة متكررة</> : form.scheduledAt ? <><CalendarDays className="w-4 h-4" /> جدولة الحملة</> : <><FileText className="w-4 h-4" /> حفظ كمسودة</>}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Campaign Detail Dialog */}
      <Dialog open={!!detailCampaign} onOpenChange={() => setDetailCampaign(null)}>
        <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto" dir="rtl">
          {detailCampaign && (
            <CampaignDetailContent
              campaign={detailCampaign}
              recipients={recipients}
              recipientStatusBadge={recipientStatusBadge}
              exportReport={exportReport}
              onResendFailed={resendFailed}
              onSend={async () => {
                const { error } = await invokeCloud("send-campaign", {
                  body: { campaign_id: detailCampaign.id },
                });
                if (error) {
                  toast.error("فشل إرسال الحملة: " + error.message);
                } else {
                  toast.success("بدأ إرسال الحملة!");
                  setDetailCampaign(null);
                  load();
                }
              }}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Campaign Comparison Dialog */}
      <Dialog open={showCompare} onOpenChange={(v) => { if (!v) { setShowCompare(false); } }}>
        <DialogContent className="max-w-4xl max-h-[85vh] overflow-y-auto" dir="rtl">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><GitCompareArrows className="w-5 h-5 text-primary" /> مقارنة الحملات</DialogTitle></DialogHeader>
          {(() => {
            const c1 = campaigns.find((c) => c.id === compareIds[0]);
            const c2 = campaigns.find((c) => c.id === compareIds[1]);
            if (!c1 || !c2) return <p className="text-sm text-muted-foreground text-center py-8">اختر حملتين للمقارنة</p>;

            const rate = (num: number, den: number) => den > 0 ? Math.round((num / den) * 100) : 0;
            const c1DeliveryRate = rate(c1.delivered_count || 0, c1.sent_count || 0);
            const c2DeliveryRate = rate(c2.delivered_count || 0, c2.sent_count || 0);
            const c1ReadRate = rate(c1.read_count || 0, c1.delivered_count || 0);
            const c2ReadRate = rate(c2.read_count || 0, c2.delivered_count || 0);
            const c1FailRate = rate(c1.failed_count || 0, c1.total_recipients || 0);
            const c2FailRate = rate(c2.failed_count || 0, c2.total_recipients || 0);

            const rows: { label: string; v1: string | number; v2: string | number; better?: "high" | "low" }[] = [
              { label: "الحالة", v1: statusConfig[c1.status]?.label || c1.status, v2: statusConfig[c2.status]?.label || c2.status },
              { label: "القالب", v1: c1.template_name || "—", v2: c2.template_name || "—" },
              { label: "إجمالي الجمهور", v1: c1.total_recipients || 0, v2: c2.total_recipients || 0, better: "high" },
              { label: "رسائل مُرسلة", v1: c1.sent_count || 0, v2: c2.sent_count || 0, better: "high" },
              { label: "تم التوصيل", v1: c1.delivered_count || 0, v2: c2.delivered_count || 0, better: "high" },
              { label: "تمت القراءة", v1: c1.read_count || 0, v2: c2.read_count || 0, better: "high" },
              { label: "فشل", v1: c1.failed_count || 0, v2: c2.failed_count || 0, better: "low" },
              { label: "معدل التوصيل", v1: `${c1DeliveryRate}%`, v2: `${c2DeliveryRate}%`, better: "high" },
              { label: "معدل القراءة", v1: `${c1ReadRate}%`, v2: `${c2ReadRate}%`, better: "high" },
              { label: "معدل الفشل", v1: `${c1FailRate}%`, v2: `${c2FailRate}%`, better: "low" },
              { label: "تاريخ الإرسال", v1: c1.sent_at ? new Date(c1.sent_at).toLocaleDateString("ar-SA-u-ca-gregory") : "—", v2: c2.sent_at ? new Date(c2.sent_at).toLocaleDateString("ar-SA-u-ca-gregory") : "—" },
            ];

            const getHighlight = (row: typeof rows[0], side: 1 | 2) => {
              if (!row.better) return "";
              const n1 = typeof row.v1 === "string" ? parseFloat(row.v1) : row.v1;
              const n2 = typeof row.v2 === "string" ? parseFloat(row.v2) : row.v2;
              if (isNaN(n1) || isNaN(n2) || n1 === n2) return "";
              const isBetter = row.better === "high" ? (side === 1 ? n1 > n2 : n2 > n1) : (side === 1 ? n1 < n2 : n2 < n1);
              return isBetter ? "text-success font-bold" : "text-muted-foreground";
            };

            return (
              <div className="mt-4 space-y-4">
                {/* Header */}
                <div className="grid grid-cols-3 gap-3">
                  <div />
                  <div className="bg-primary/5 rounded-lg p-3 text-center">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center mx-auto mb-2">
                      <Megaphone className="w-5 h-5 text-primary" />
                    </div>
                    <p className="font-bold text-sm truncate">{c1.name}</p>
                  </div>
                  <div className="bg-secondary rounded-lg p-3 text-center">
                    <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center mx-auto mb-2">
                      <Megaphone className="w-5 h-5 text-muted-foreground" />
                    </div>
                    <p className="font-bold text-sm truncate">{c2.name}</p>
                  </div>
                </div>

                {/* Comparison table */}
                <div className="border border-border rounded-xl overflow-hidden">
                  {rows.map((row, i) => (
                    <div key={row.label} className={cn("grid grid-cols-3 gap-3 px-4 py-2.5 text-sm", i % 2 === 0 ? "bg-secondary/30" : "bg-card")}>
                      <p className="text-muted-foreground text-xs font-medium">{row.label}</p>
                      <p className={cn("text-center font-semibold", getHighlight(row, 1))}>{typeof row.v1 === "number" ? row.v1.toLocaleString() : row.v1}</p>
                      <p className={cn("text-center font-semibold", getHighlight(row, 2))}>{typeof row.v2 === "number" ? row.v2.toLocaleString() : row.v2}</p>
                    </div>
                  ))}
                </div>

                {/* Visual bars */}
                <div className="space-y-4">
                  <h3 className="text-xs font-semibold text-muted-foreground">مقارنة بصرية</h3>
                  {[
                    { label: "معدل التوصيل", v1: c1DeliveryRate, v2: c2DeliveryRate },
                    { label: "معدل القراءة", v1: c1ReadRate, v2: c2ReadRate },
                    { label: "معدل الفشل", v1: c1FailRate, v2: c2FailRate },
                  ].map((bar) => (
                    <div key={bar.label} className="space-y-1.5">
                      <p className="text-xs text-muted-foreground">{bar.label}</p>
                      <div className="flex items-center gap-3">
                        <span className="text-[10px] w-20 text-left truncate">{c1.name}</span>
                        <div className="flex-1 bg-secondary rounded-full h-3 overflow-hidden">
                          <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${bar.v1}%` }} />
                        </div>
                        <span className="text-xs font-bold w-10">{bar.v1}%</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-[10px] w-20 text-left truncate">{c2.name}</span>
                        <div className="flex-1 bg-secondary rounded-full h-3 overflow-hidden">
                          <div className="h-full bg-muted-foreground rounded-full transition-all" style={{ width: `${bar.v2}%` }} />
                        </div>
                        <span className="text-xs font-bold w-10">{bar.v2}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })()}
        </DialogContent>
      </Dialog>
    </div>
  );
};

// ═══════════════════════════════════════════════
// Campaign Detail with Advanced Analytics
// ═══════════════════════════════════════════════

function CampaignDetailContent({
  campaign,
  recipients,
  recipientStatusBadge,
  exportReport,
  onSend,
  onResendFailed,
}: {
  campaign: any;
  recipients: any[];
  recipientStatusBadge: (status: string) => JSX.Element;
  exportReport: () => void;
  onSend?: () => void;
  onResendFailed?: () => void;
}) {
  const total = campaign.total_recipients || 0;
  const sent = campaign.sent_count || 0;
  const delivered = campaign.delivered_count || 0;
  const read = campaign.read_count || 0;
  const failed = campaign.failed_count || 0;

  const deliveryRate = sent > 0 ? ((delivered / sent) * 100) : 0;
  const openRate = delivered > 0 ? ((read / delivered) * 100) : 0;
  const failRate = sent > 0 ? ((failed / sent) * 100) : 0;

  // Count replied recipients (those with status containing 'replied' or messages back)
  const replied = recipients.filter((r) => r.status === "replied").length;
  const replyRate = delivered > 0 ? ((replied / delivered) * 100) : 0;

  // Failure breakdown
  const failureBreakdown = useMemo(() => {
    const map: Record<string, number> = {};
    recipients.filter((r) => r.status === "failed").forEach((r) => {
      const reason = r.error_code || r.error_message || "خطأ غير محدد";
      map[reason] = (map[reason] || 0) + 1;
    });
    return Object.entries(map)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10);
  }, [recipients]);

  // Funnel data
  const funnelSteps = [
    { label: "الجمهور", value: total, color: "bg-muted-foreground" },
    { label: "مُرسلة", value: sent, color: "bg-info" },
    { label: "تم التوصيل", value: delivered, color: "bg-success" },
    { label: "تمت القراءة", value: read, color: "bg-primary" },
  ];
  const maxFunnel = Math.max(total, 1);

  return (
    <>
      <DialogHeader>
        <DialogTitle className="flex items-center justify-between">
          <span>تفاصيل: {campaign.name}</span>
          <div className="flex items-center gap-2">
            {(campaign.status === "draft" || campaign.status === "scheduled") && onSend && (
              <Button size="sm" className="text-xs gap-1 gradient-whatsapp text-whatsapp-foreground" onClick={onSend}>
                <Send className="w-3 h-3" /> إرسال الآن
              </Button>
            )}
            {failed > 0 && onResendFailed && campaign.status === "sent" && (
              <Button size="sm" variant="outline" className="text-xs gap-1 border-warning text-warning hover:bg-warning/10" onClick={onResendFailed}>
                <RotateCcw className="w-3 h-3" /> إعادة إرسال الفاشلة ({failed})
              </Button>
            )}
            <Button size="sm" variant="outline" className="text-xs gap-1" onClick={exportReport}>
              <Download className="w-3 h-3" /> تصدير Excel
            </Button>
          </div>
        </DialogTitle>
      </DialogHeader>

      <Tabs defaultValue="analytics" className="mt-2">
        <TabsList className="w-full grid grid-cols-3 h-9">
          <TabsTrigger value="analytics" className="text-xs gap-1"><BarChart3 className="w-3 h-3" /> التحليلات</TabsTrigger>
          <TabsTrigger value="recipients" className="text-xs gap-1"><Users className="w-3 h-3" /> المستلمون</TabsTrigger>
          <TabsTrigger value="info" className="text-xs gap-1"><FileText className="w-3 h-3" /> معلومات</TabsTrigger>
        </TabsList>

        {/* ── Analytics Tab ── */}
        <TabsContent value="analytics" className="space-y-4 mt-3">

          {/* Rate Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="bg-card border border-border rounded-xl p-3 text-center">
              <div className="w-8 h-8 rounded-lg bg-info/10 flex items-center justify-center mx-auto mb-2">
                <Send className="w-4 h-4 text-info" />
              </div>
              <p className="text-xl font-bold text-info">{deliveryRate.toFixed(1)}%</p>
              <p className="text-[10px] text-muted-foreground">معدل التوصيل</p>
              <p className="text-[9px] text-muted-foreground mt-0.5">{delivered.toLocaleString()} / {sent.toLocaleString()}</p>
            </div>
            <div className="bg-card border border-border rounded-xl p-3 text-center">
              <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center mx-auto mb-2">
                <MailOpen className="w-4 h-4 text-primary" />
              </div>
              <p className="text-xl font-bold text-primary">{openRate.toFixed(1)}%</p>
              <p className="text-[10px] text-muted-foreground">معدل الفتح</p>
              <p className="text-[9px] text-muted-foreground mt-0.5">{read.toLocaleString()} / {delivered.toLocaleString()}</p>
            </div>
            <div className="bg-card border border-border rounded-xl p-3 text-center">
              <div className="w-8 h-8 rounded-lg bg-success/10 flex items-center justify-center mx-auto mb-2">
                <Reply className="w-4 h-4 text-success" />
              </div>
              <p className="text-xl font-bold text-success">{replyRate.toFixed(1)}%</p>
              <p className="text-[10px] text-muted-foreground">معدل الرد</p>
              <p className="text-[9px] text-muted-foreground mt-0.5">{replied.toLocaleString()} / {delivered.toLocaleString()}</p>
            </div>
            <div className="bg-card border border-border rounded-xl p-3 text-center">
              <div className="w-8 h-8 rounded-lg bg-destructive/10 flex items-center justify-center mx-auto mb-2">
                <XCircle className="w-4 h-4 text-destructive" />
              </div>
              <p className="text-xl font-bold text-destructive">{failRate.toFixed(1)}%</p>
              <p className="text-[10px] text-muted-foreground">معدل الفشل</p>
              <p className="text-[9px] text-muted-foreground mt-0.5">{failed.toLocaleString()} / {sent.toLocaleString()}</p>
            </div>
          </div>

          {/* Visual Funnel */}
          <div className="bg-card border border-border rounded-xl p-4">
            <h3 className="text-sm font-bold mb-4 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-primary" /> قمع التحويل
            </h3>
            <div className="space-y-3">
              {funnelSteps.map((step, i) => {
                const pct = (step.value / maxFunnel) * 100;
                const dropoff = i > 0 ? funnelSteps[i - 1].value - step.value : 0;
                const dropoffPct = i > 0 && funnelSteps[i - 1].value > 0 ? ((dropoff / funnelSteps[i - 1].value) * 100) : 0;
                return (
                  <div key={step.label}>
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="font-medium">{step.label}</span>
                      <div className="flex items-center gap-2">
                        <span className="font-bold">{step.value.toLocaleString()}</span>
                        {i > 0 && dropoff > 0 && (
                          <span className="text-[10px] text-destructive/70">-{dropoff.toLocaleString()} ({dropoffPct.toFixed(0)}%)</span>
                        )}
                      </div>
                    </div>
                    <div className="h-6 bg-secondary rounded-lg overflow-hidden">
                      <div
                        className={cn("h-full rounded-lg transition-all duration-700", step.color)}
                        style={{ width: `${Math.max(pct, 2)}%`, opacity: 0.8 }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Failure Breakdown */}
          {failureBreakdown.length > 0 && (
            <div className="bg-card border border-border rounded-xl p-4">
              <h3 className="text-sm font-bold mb-3 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-destructive" /> تفصيل أسباب الفشل
              </h3>
              <div className="space-y-2">
                {failureBreakdown.map(([reason, count]) => {
                  const pct = failed > 0 ? ((count / failed) * 100) : 0;
                  return (
                    <div key={reason} className="flex items-center gap-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between text-xs mb-0.5">
                          <span className="text-muted-foreground truncate font-mono text-[10px]" dir="ltr">{reason}</span>
                          <span className="text-destructive font-bold shrink-0 mr-2">{count}</span>
                        </div>
                        <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
                          <div className="h-full bg-destructive/60 rounded-full" style={{ width: `${pct}%` }} />
                        </div>
                      </div>
                      <span className="text-[10px] text-muted-foreground shrink-0 w-10 text-left">{pct.toFixed(0)}%</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Summary Numbers */}
          <div className="grid grid-cols-5 gap-2">
            <div className="bg-secondary rounded-lg p-2.5 text-center">
              <p className="text-base font-bold">{total.toLocaleString()}</p>
              <p className="text-[9px] text-muted-foreground">الإجمالي</p>
            </div>
            <div className="bg-info/5 rounded-lg p-2.5 text-center">
              <p className="text-base font-bold text-info">{sent.toLocaleString()}</p>
              <p className="text-[9px] text-muted-foreground">مُرسلة</p>
            </div>
            <div className="bg-success/5 rounded-lg p-2.5 text-center">
              <p className="text-base font-bold text-success">{delivered.toLocaleString()}</p>
              <p className="text-[9px] text-muted-foreground">وصلت</p>
            </div>
            <div className="bg-primary/5 rounded-lg p-2.5 text-center">
              <p className="text-base font-bold text-primary">{read.toLocaleString()}</p>
              <p className="text-[9px] text-muted-foreground">مقروءة</p>
            </div>
            <div className="bg-destructive/5 rounded-lg p-2.5 text-center">
              <p className="text-base font-bold text-destructive">{failed.toLocaleString()}</p>
              <p className="text-[9px] text-muted-foreground">فشل</p>
            </div>
          </div>
        </TabsContent>

        {/* ── Recipients Tab ── */}
        <TabsContent value="recipients" className="mt-3">
          <div className="border border-border rounded-lg overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-secondary/50 text-muted-foreground text-[11px]">
                  <th className="text-right p-2.5">الرقم</th>
                  <th className="text-right p-2.5">الاسم</th>
                  <th className="text-right p-2.5">الحالة</th>
                  <th className="text-right p-2.5 hidden md:table-cell">وقت الإرسال</th>
                  <th className="text-right p-2.5 hidden md:table-cell">وقت التوصيل</th>
                  <th className="text-right p-2.5 hidden lg:table-cell">الخطأ</th>
                </tr>
              </thead>
              <tbody>
                {recipients.map((r) => (
                  <tr key={r.id} className={cn("border-b border-border/50 hover:bg-secondary/20", r.status === "failed" && "bg-destructive/5")}>
                    <td className="p-2.5 font-mono text-xs" dir="ltr">{r.phone}</td>
                    <td className="p-2.5 text-xs">{r.customer_name || "-"}</td>
                    <td className="p-2.5">
                      {recipientStatusBadge(r.status)}
                      {r.status === "failed" && r.error_message && (
                        <p className="text-[9px] text-destructive mt-0.5 max-w-[200px] truncate" title={`${r.error_code ? r.error_code + ": " : ""}${r.error_message}`}>
                          {r.error_code && <span className="font-mono">{r.error_code} — </span>}
                          {r.error_message}
                        </p>
                      )}
                    </td>
                    <td className="p-2.5 text-[10px] text-muted-foreground hidden md:table-cell">{r.sent_at ? new Date(r.sent_at).toLocaleString("ar-SA-u-ca-gregory") : "-"}</td>
                    <td className="p-2.5 text-[10px] text-muted-foreground hidden md:table-cell">{r.delivered_at ? new Date(r.delivered_at).toLocaleString("ar-SA-u-ca-gregory") : "-"}</td>
                    <td className="p-2.5 text-[10px] text-destructive hidden lg:table-cell">
                      {r.error_code && <span className="font-mono">{r.error_code}: </span>}
                      {r.error_message || "-"}
                    </td>
                  </tr>
                ))}

                {recipients.length === 0 && (
                  <tr><td colSpan={6} className="text-center py-6 text-muted-foreground text-xs">لا يوجد مستلمين</td></tr>
                )}
              </tbody>
            </table>
          </div>
          {recipients.length >= 500 && (
            <p className="text-[10px] text-muted-foreground text-center mt-2">يتم عرض أول 500 مستلم — صدّر التقرير للقائمة الكاملة</p>
          )}
        </TabsContent>

        {/* ── Info Tab ── */}
        <TabsContent value="info" className="mt-3 space-y-3">
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="bg-secondary rounded-lg p-3">
              <p className="text-muted-foreground text-[10px]">القالب</p>
              <p className="font-semibold mt-0.5">{campaign.template_name || "-"}</p>
            </div>
            <div className="bg-secondary rounded-lg p-3">
              <p className="text-muted-foreground text-[10px]">نوع الجمهور</p>
              <p className="font-semibold mt-0.5">
                {campaign.audience_type === "all" ? "الكل" : campaign.audience_type === "tags" ? "تصنيفات" : campaign.audience_type === "upload" ? "إكسل" : campaign.audience_type === "select" ? "يدوي" : campaign.audience_type === "orders" ? "طلبات" : campaign.audience_type}
              </p>
            </div>
            <div className="bg-secondary rounded-lg p-3">
              <p className="text-muted-foreground text-[10px]">تاريخ الإنشاء</p>
              <p className="font-semibold mt-0.5">{new Date(campaign.created_at).toLocaleString("ar-SA-u-ca-gregory")}</p>
            </div>
            <div className="bg-secondary rounded-lg p-3">
              <p className="text-muted-foreground text-[10px]">تاريخ الإرسال</p>
              <p className="font-semibold mt-0.5">{campaign.sent_at ? new Date(campaign.sent_at).toLocaleString("ar-SA-u-ca-gregory") : "-"}</p>
            </div>
          </div>
          {campaign.audience_tags?.length > 0 && (
            <div className="bg-secondary rounded-lg p-3">
              <p className="text-muted-foreground text-[10px] mb-1">التصنيفات المستهدفة</p>
              <div className="flex flex-wrap gap-1">
                {campaign.audience_tags.map((t: string) => (
                  <Badge key={t} variant="outline" className="text-[10px]">{t}</Badge>
                ))}
              </div>
            </div>
          )}
          {campaign.exclude_tags?.length > 0 && (
            <div className="bg-destructive/5 rounded-lg p-3">
              <p className="text-destructive text-[10px] mb-1">التصنيفات المستثناة</p>
              <div className="flex flex-wrap gap-1">
                {campaign.exclude_tags.map((t: string) => (
                  <Badge key={t} variant="outline" className="text-[10px] border-destructive/30 text-destructive">{t}</Badge>
                ))}
              </div>
            </div>
          )}
          {campaign.notes && (
            <div className="bg-secondary rounded-lg p-3">
              <p className="text-muted-foreground text-[10px]">ملاحظات</p>
              <p className="text-xs mt-0.5">{campaign.notes}</p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </>
  );
}

export default CampaignsPage;

